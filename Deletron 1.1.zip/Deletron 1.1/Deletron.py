import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import os
import shutil
import time
from PIL import Image, ImageTk
import json


class NexusAvatar:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Deletron")
        self.root.overrideredirect(True)
        self.root.attributes('-topmost', True)
        self.root.configure(bg='white')
        self.root.attributes('-alpha', 0.9)  # Полупрозрачность

        # Конфигурация
        self.config_file = "Deletron_config.json"
        self.load_config()

        # Основной фрейм
        self.main_frame = tk.Frame(self.root, bg='white', relief='solid', bd=2)
        self.main_frame.pack(padx=5, pady=5)

        # Canvas для аватара
        self.canvas = tk.Canvas(self.main_frame, width=150, height=150,
                                bg='white', highlightthickness=0)
        self.canvas.pack(pady=5)

        # Загрузка изображения
        self.tk_image = None
        self.load_avatar_image()

        # Элементы управления
        self.create_controls()
        self.setup_interaction()

        # Позиционирование
        self.set_position()

    def load_config(self):
        """Загрузка конфигурации"""
        self.config = {
            "avatar_image": "",
            "position": {"x": 100, "y": 100},
            "size": 150
        }
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    self.config.update(json.load(f))
            except:
                pass

    def save_config(self):
        """Сохранение конфигурации"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
        except:
            pass

    def load_avatar_image(self):
        """Загрузка изображения аватара"""
        try:
            if self.config["avatar_image"] and os.path.exists(self.config["avatar_image"]):
                image = Image.open(self.config["avatar_image"])
            else:
                image = self.create_default_avatar()

            image = image.resize((140, 140), Image.Resampling.LANCZOS)
            self.tk_image = ImageTk.PhotoImage(image)
            self.canvas.create_image(75, 75, image=self.tk_image, tags="avatar")

        except Exception as e:
            print(f"Ошибка загрузки изображения: {e}")
            self.create_default_drawing()

    def create_default_avatar(self):
        """Создание дефолтного аватара"""
        from PIL import ImageDraw

        img = Image.new('RGBA', (200, 200), (255, 255, 255, 0))
        draw = ImageDraw.Draw(img)

        # Рисуем стильного аватара
        draw.ellipse((20, 20, 180, 180), fill='#4FC3F7', outline='#0288D1', width=4)

        # Глаза
        draw.ellipse((70, 70, 90, 90), fill='white', outline='#01579B', width=2)
        draw.ellipse((110, 70, 130, 90), fill='white', outline='#01579B', width=2)
        draw.ellipse((75, 75, 85, 85), fill='#01579B')
        draw.ellipse((115, 75, 125, 85), fill='#01579B')

        # Улыбка
        draw.arc((60, 100, 140, 140), 0, 180, fill='#01579B', width=3)

        # Сохраняем как дефолтное
        if not os.path.exists("default_avatar.png"):
            img.save("default_avatar.png", "PNG")
            self.config["avatar_image"] = "default_avatar.png"

        return img

    def create_default_drawing(self):
        """Резервное рисование на canvas"""
        self.canvas.delete("all")
        # Голова
        self.canvas.create_oval(15, 15, 135, 135, fill='#4FC3F7', outline='#0288D1', width=3)

        # Глаза
        self.canvas.create_oval(55, 55, 75, 75, fill='white', outline='#01579B', width=2)
        self.canvas.create_oval(95, 55, 115, 75, fill='white', outline='#01579B', width=2)
        self.canvas.create_oval(60, 60, 70, 70, fill='#01579B')
        self.canvas.create_oval(100, 60, 110, 70, fill='#01579B')

        # Рот
        self.canvas.create_arc(50, 80, 120, 120, start=0, extent=-180,
                               style=tk.ARC, width=3, outline='#01579B')

        # Текст
        self.canvas.create_text(75, 140, text="Nexus", font=("Arial", 8, "bold"),
                                fill='#01579B')

    def create_controls(self):
        """Создание элементов управления"""
        # Статус
        self.status = tk.Label(self.main_frame, text="👾 Deletron",
                               bg='white', font=("Arial", 9), fg='#333333')
        self.status.pack(pady=3)

        # Кнопки управления
        btn_frame = tk.Frame(self.main_frame, bg='white')
        btn_frame.pack(pady=5)

        # Кнопка смены изображения
        tk.Button(btn_frame, text="🖼️", font=("Arial", 12),
                  command=self.change_image, bg='#E3F2FD', width=2,
                  relief='flat', cursor='hand2').pack(side=tk.LEFT, padx=2)

        # Кнопка удаления файлов
        tk.Button(btn_frame, text="🗑️", font=("Arial", 12),
                  command=self.delete_files, bg='#FFEBEE', width=2,
                  relief='flat', cursor='hand2').pack(side=tk.LEFT, padx=2)

        # Кнопка скрытия
        tk.Button(btn_frame, text="👁️", font=("Arial", 12),
                  command=self.toggle_visibility, bg='#E8F5E8', width=2,
                  relief='flat', cursor='hand2').pack(side=tk.LEFT, padx=2)

        # Кнопка закрытия
        tk.Button(btn_frame, text="❌", font=("Arial", 10),
                  command=self.root.quit, bg='#FCE4EC', width=2,
                  relief='flat', cursor='hand2').pack(side=tk.LEFT, padx=2)

    def change_image(self):
        """Смена изображения аватара"""
        filename = filedialog.askopenfilename(
            title="Выберите изображение для аватара",
            filetypes=[
                ("Изображения", "*.png *.jpg *.jpeg *.gif *.bmp"),
                ("Все файлы", "*.*")
            ]
        )
        if filename:
            try:
                self.config["avatar_image"] = filename
                self.save_config()
                self.load_avatar_image()
                self.status.config(text="✅ Изображение обновлено!")
                self.root.after(2000, lambda: self.status.config(text="👾 Deletron"))
            except Exception as e:
                messagebox.showerror("Ошибка", f"Не удалось загрузить изображение:\n{e}")

    def delete_files(self):
        """Удаление файлов через диалог"""
        files = filedialog.askopenfilenames(
            title="Выберите файлы для удаления",
            filetypes=[("Все файлы", "*.*")]
        )

        if files:
            file_count = len(files)
            file_list = "\n".join([os.path.basename(f) for f in files[:3]])
            if file_count > 3:
                file_list += f"\n... и ещё {file_count - 3} файлов"

            result = messagebox.askyesno(
                "Подтверждение удаления",
                f"УДАЛИТЬ НАВСЕГДА {file_count} файлов?\n\n"
                f"Файлы будут удалены без возможности восстановления!\n\n"
                f"{file_list}",
                icon='warning'
            )

            if result:
                self.process_deletion(files)

    def process_deletion(self, files):
        """Обработка удаления файлов"""
        # Прогресс бар
        progress = ttk.Progressbar(self.main_frame, orient='horizontal',
                                   length=140, mode='determinate')
        progress.pack(pady=5)
        progress['maximum'] = len(files)

        deleted = 0
        for i, file_path in enumerate(files):
            try:
                if os.path.exists(file_path):
                    if os.path.isfile(file_path):
                        os.remove(file_path)
                        deleted += 1
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                        deleted += 1

                progress['value'] = i + 1
                self.status.config(text=f"🗑️ Удаление... {i + 1}/{len(files)}")
                self.root.update()
                time.sleep(0.05)  # Небольшая задержка для анимации

            except Exception as e:
                print(f"Ошибка удаления {file_path}: {e}")

        progress.destroy()

        if deleted > 0:
            self.status.config(text=f"✅ Удалено: {deleted}/{len(files)}")
            # Анимация успеха
            self.animate_success()
        else:
            self.status.config(text="❌ Ошибка удаления!")

        self.root.after(3000, lambda: self.status.config(text="👾 Deletron"))

    def animate_success(self):
        """Анимация при успешном удалении"""
        original_color = self.canvas['bg']
        for color in ['#C8E6C9', '#A5D6A7', original_color]:
            self.canvas.config(bg=color)
            self.root.update()
            self.root.after(100)

    def toggle_visibility(self):
        """Переключение видимости"""
        if self.main_frame.winfo_ismapped():
            self.main_frame.pack_forget()
            self.status.config(text="👁️‍🗨️ Скрыт")
        else:
            self.main_frame.pack(padx=5, pady=5)
            self.status.config(text="👾 Deletron")

    def setup_interaction(self):
        """Настройка взаимодействия"""
        # Перетаскивание окна
        self.canvas.bind("<Button-1>", self.start_drag)
        self.canvas.bind("<B1-Motion>", self.on_drag)

        # Двойной клик для смены изображения
        self.canvas.bind("<Double-Button-1>", lambda e: self.change_image())

        # Правый клик для меню
        self.canvas.bind("<Button-3>", self.show_context_menu)

        # Изменение курсора
        self.canvas.bind("<Enter>", lambda e: self.canvas.config(cursor="hand2"))
        self.canvas.bind("<Leave>", lambda e: self.canvas.config(cursor=""))

    def start_drag(self, event):
        """Начало перетаскивания"""
        self.drag_start_x = event.x
        self.drag_start_y = event.y

    def on_drag(self, event):
        """Перетаскивание окна"""
        x = self.root.winfo_x() + (event.x - self.drag_start_x)
        y = self.root.winfo_y() + (event.y - self.drag_start_y)
        self.root.geometry(f"+{x}+{y}")
        self.config["position"] = {"x": x, "y": y}
        self.save_config()

    def show_context_menu(self, event):
        """Контекстное меню"""
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="🖼️ Сменить изображение", command=self.change_image)
        menu.add_command(label="🗑️ Удалить файлы", command=self.delete_files)
        menu.add_separator()
        menu.add_command(label="👁️ Скрыть/Показать", command=self.toggle_visibility)
        menu.add_command(label="⚙️ Настройки", command=self.show_settings)
        menu.add_separator()
        menu.add_command(label="❌ Выход", command=self.root.quit)
        menu.post(event.x_root, event.y_root)

    def show_settings(self):
        """Окно настроек"""
        settings = tk.Toplevel(self.root)
        settings.title("Настройки Deletron")
        settings.geometry("250x150")
        settings.resizable(False, False)
        settings.transient(self.root)
        settings.grab_set()

        tk.Label(settings, text="⚙️ Настройки Deletron", font=("Arial", 12, "bold")).pack(pady=10)

        # Прозрачность
        opacity_frame = tk.Frame(settings)
        opacity_frame.pack(pady=5, fill='x', padx=20)

        tk.Label(opacity_frame, text="Прозрачность:").pack(side=tk.LEFT)
        opacity_var = tk.DoubleVar(value=self.root.attributes('-alpha'))
        opacity_scale = tk.Scale(opacity_frame, from_=0.3, to=1.0, resolution=0.1,
                                 orient=tk.HORIZONTAL, variable=opacity_var,
                                 command=lambda v: self.root.attributes('-alpha', float(v)))
        opacity_scale.pack(side=tk.RIGHT, fill='x', expand=True)

        # Кнопка сброса
        tk.Button(settings, text="🔄 Сбросить настройки",
                  command=self.reset_settings).pack(pady=10)

        tk.Button(settings, text="Закрыть",
                  command=settings.destroy).pack(pady=5)

    def reset_settings(self):
        """Сброс настроек"""
        self.config = {
            "avatar_image": "",
            "position": {"x": 100, "y": 100},
            "size": 150
        }
        self.save_config()
        messagebox.showinfo("Сброс", "Настройки сброшены!")
        self.load_avatar_image()

    def set_position(self):
        """Установка позиции окна"""
        if "position" in self.config:
            pos = self.config["position"]
            self.root.geometry(f"+{pos['x']}+{pos['y']}")
        else:
            # Позиция по умолчанию - правый верхний угол
            screen_width = self.root.winfo_screenwidth()
            self.root.geometry(f"+{screen_width - 180}+50")

    def run(self):
        """Запуск приложения"""
        self.root.mainloop()


# Запуск приложения
if __name__ == "__main__":
    app = NexusAvatar()
    app.run()