@echo off
start pythonw.exe "Deletron.py"
exit